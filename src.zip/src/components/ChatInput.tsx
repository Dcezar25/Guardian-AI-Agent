import { useState, useEffect, useRef } from "react";
import type { KeyboardEvent, ChangeEvent } from "react";
import { useUser } from "../context/UserContext";
import { FiPlus, FiX } from "react-icons/fi";

export default function ChatInput() {
  const [text, setText] = useState("");
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [fileDialog, setFileDialog] = useState<{ type: "pdf" | "image"; show: boolean }>({ type: "pdf", show: false });
  const [alert, setAlert] = useState<string | null>(null);

  const { addMessage } = useUser();

  const dropdownRef = useRef<HTMLDivElement>(null);

  // ✅ Click outside dropdown -> close
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleSend = () => {
    if (!text.trim()) return;
    addMessage({ sender: "user", text });
    setText("");

    setTimeout(() => {
      addMessage({
        sender: "guardian",
        text: "I am listening. Please tell me what is happening.",
      });
    }, 500);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleSend();
  };

  const handleFile = (e: ChangeEvent<HTMLInputElement>, type: "pdf" | "image") => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (type === "pdf" && file.type !== "application/pdf") {
      setAlert("Only PDF files are allowed!");
      return;
    }
    if (type === "image" && !["image/png", "image/jpeg"].includes(file.type)) {
      setAlert("Only PNG or JPEG images are allowed!");
      return;
    }

    addMessage({ sender: "user", file, fileType: type });
    setFileDialog({ ...fileDialog, show: false });
    setDropdownOpen(false); // ✅ închidem dropdown-ul după upload
  };

  return (
    <div className="w-full p-4 flex flex-col items-center space-y-2 bg-gray-900">
      <div className="flex items-center space-x-2 w-full relative">
        <div ref={dropdownRef} className="relative">
          <button className="p-2 bg-gray-700 rounded" onClick={() => setDropdownOpen(!dropdownOpen)}>
            <FiPlus size={24} />
          </button>

          {dropdownOpen && (
            <div className="absolute bottom-12 left-0 bg-gray-800 text-white p-2 rounded shadow-lg flex flex-col space-y-1 z-50">
              <button
                className="hover:bg-gray-700 px-2 py-1 rounded"
                onClick={() => setFileDialog({ type: "pdf", show: true })}
              >
                Add Document
              </button>
              <button
                className="hover:bg-gray-700 px-2 py-1 rounded"
                onClick={() => setFileDialog({ type: "image", show: true })}
              >
                Add Image
              </button>
            </div>
          )}
        </div>

        <input
          type="text"
          placeholder="Type your message..."
          className="flex-1 p-3 rounded-lg bg-slate-800 text-white outline-none"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
        />
        <button
          onClick={handleSend}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded font-semibold"
        >
          Send
        </button>
      </div>

      {/* File Dialog */}
      {fileDialog.show && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 text-white p-6 rounded-lg w-96 relative">
            <button
              className="absolute top-2 right-2"
              onClick={() => setFileDialog({ ...fileDialog, show: false })}
            >
              <FiX size={24} />
            </button>
            <p className="mb-4">
              {fileDialog.type === "pdf" ? "Upload a PDF document" : "Upload an image (PNG/JPEG)"}
            </p>
            <input
              type="file"
              accept={fileDialog.type === "pdf" ? "application/pdf" : "image/png, image/jpeg"}
              onChange={(e) => handleFile(e, fileDialog.type)}
            />
          </div>
        </div>
      )}

      {/* Alert */}
      {alert && (
        <div className="fixed top-10 left-1/2 transform -translate-x-1/2 bg-red-600 text-white p-4 rounded z-50 flex items-center justify-between">
          <span>{alert}</span>
          <button onClick={() => setAlert(null)}>
            <FiX />
          </button>
        </div>
      )}
    </div>
  );
}
