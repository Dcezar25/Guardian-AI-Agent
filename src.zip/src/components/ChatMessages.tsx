import { useEffect, useRef } from "react";
import { useUser } from "../context/UserContext";
import { FiFile } from "react-icons/fi";

export default function ChatMessages() {
  const { conversations, activeConversationId } = useUser();
  const containerRef = useRef<HTMLDivElement>(null);

  const activeConversation = conversations.find(c => c.id === activeConversationId);

  useEffect(() => {
    if (containerRef.current) {
      containerRef.current.scrollTop = containerRef.current.scrollHeight;
    }
  }, [activeConversation?.messages]);

  if (!activeConversation) return null;

  // 🔹 Funcție helper pentru afișarea fișierelor
  const renderFile = (msg: { file?: File; fileType?: "pdf" | "image" }) => {
    if (!msg.file) return null;

    const file: File = msg.file; // ✅ sigur File

    if (msg.fileType === "pdf") {
      const handleOpen = () => {
        const fileURL = URL.createObjectURL(file);
        const newWindow = window.open(fileURL);
        if (!newWindow) {
          alert("Could not open file. Please check your popup blocker.");
        }
      };

      return (
        <div
          className="mt-2 flex items-center space-x-2 cursor-pointer hover:bg-gray-700 p-2 rounded"
          onClick={handleOpen}
        >
          <FiFile size={24} />
          <span>{file.name}</span>
        </div>
      );
    }

    if (msg.fileType === "image") {
      return (
        <div className="mt-2">
          <img
            src={URL.createObjectURL(file)}
            alt={file.name}
            className="max-w-full rounded"
          />
        </div>
      );
    }

    return null;
  };

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto p-6 space-y-4 max-h-full">
      {activeConversation.messages.map((msg, index) => (
        <div
          key={index}
          className={`max-w-xl p-4 rounded-xl text-white break-words ${
            msg.sender === "guardian"
              ? "bg-blue-700 self-start"
              : "bg-slate-700 self-end ml-auto"
          }`}
        >
          {msg.text && <span>{msg.text}</span>}
          {renderFile(msg)}
        </div>
      ))}
    </div>
  );
}
