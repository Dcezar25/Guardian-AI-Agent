import { createContext, useContext, useState } from "react";
import type { ReactNode } from "react";

export type Message = {
  sender: "user" | "guardian";
  text?: string;
  file?: File;
  fileType?: "pdf" | "image";
};

export type Conversation = {
  id: string;
  messages: Message[];
};

type UserContextType = {
  conversations: Conversation[];
  activeConversationId: string | null;
  setActiveConversation: (id: string) => void;
  newConversation: () => void;
  addMessage: (msg: Message) => void;
  downloadConversation: (id: string | null) => void;
};

const UserContext = createContext<UserContextType | null>(null);

export function UserProvider({ children }: { children: ReactNode }) {
  const [conversations, setConversations] = useState<Conversation[]>([
    {
      id: crypto.randomUUID(),
      messages: [
        {
          sender: "guardian",
          text: "Hello. I am The Guardian. I am here to protect, guide, and support you. You are safe here.",
        },
      ],
    },
  ]);
  const [activeConversationId, setActiveConversationId] = useState<string | null>(conversations[0].id);

  const setActiveConversation = (id: string) => {
    setActiveConversationId(id);
  };

  const newConversation = () => {
    const id = crypto.randomUUID();

    // Mesajul de întâmpinare
    const greetingMsg: Message = {
        sender: "guardian",
        text: "Hello. I am The Guardian. I am here to protect, guide, and support you. You are safe here.",
    };

    const conv: Conversation = {
        id,
        messages: [greetingMsg], // adaugă mesajul direct
    };

    setConversations(prev => [conv, ...prev]);
    setActiveConversationId(id);
    };


  const addMessage = (msg: Message) => {
    if (!activeConversationId) return;
    setConversations(prev =>
      prev.map(conv =>
        conv.id === activeConversationId
          ? { ...conv, messages: [...conv.messages, msg] }
          : conv
      )
    );
  };

  const downloadConversation = (id: string | null) => {
    if (!id) return;
    const conv = conversations.find(c => c.id === id);
    if (!conv) return;

    const text = conv.messages
      .map(m => {
        if (m.text) return `${m.sender}: ${m.text}`;
        if (m.fileType) return `${m.sender}: uploaded ${m.fileType.toUpperCase()}`;
        return `${m.sender}: [unknown content]`;
      })
      .join("\n\n");

    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `conversation_${id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <UserContext.Provider
      value={{
        conversations,
        activeConversationId,
        setActiveConversation,
        newConversation,
        addMessage,
        downloadConversation,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (!context) throw new Error("useUser must be used inside UserProvider");
  return context;
}
