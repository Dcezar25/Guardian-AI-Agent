import Header from "./components/Header";
import ChatInput from "./components/ChatInput";
import Sidebar from "./components/Sidebar";
import { UserProvider } from "./context/UserContext";
import ChatMessages from "./components/ChatMessages";

export default function App() {
  return (
    <UserProvider>
      <div className="flex flex-col h-screen bg-[#0b1c2d]">
        {/* HEADER */}
        <Header />

        <div className="flex flex-1 overflow-hidden">
          {/* SIDEBAR */}
          <Sidebar />

          {/* CHAT */}
          <div className="flex-1 flex flex-col">
            {/* Mesaje - doar aici avem scroll */}
            <div className="flex-1 overflow-y-auto">
              <ChatMessages />
            </div>

            {/* Input */}
            <ChatInput />
          </div>
        </div>
      </div>
    </UserProvider>
  );
}
