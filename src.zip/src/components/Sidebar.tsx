// src/components/Sidebar.tsx
import { useRef, useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import type { Conversation, Message } from "../context/UserContext";
import {
  FiSearch,
  FiDownload,
  FiPlus,
  FiAlertCircle,
  FiX,
  FiSettings,
} from "react-icons/fi";
import { GiAngelWings } from "react-icons/gi";
import InfoBox from "./InfoBox";

export default function Sidebar() {
  const sidebarRef = useRef<HTMLDivElement>(null);
  const [showConversations, setShowConversations] = useState(false);
  const [panicOpen, setPanicOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const [helperNumber, setHelperNumber] = useState<string>("");

  const {
    conversations,
    activeConversationId,
    setActiveConversation,
    newConversation,
    downloadConversation,
  } = useUser();

  // Load number from localStorage
  useEffect(() => {
    const saved = localStorage.getItem("HELPER_NUMBER");
    if (saved) setHelperNumber(saved);
  }, []);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (sidebarRef.current && !sidebarRef.current.contains(event.target as Node)) {
        setShowConversations(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Titlu conversație: primele 3 cuvinte ale userului sau "No title"
  const getConversationTitle = (conv: Conversation) => {
    const userMsg = conv.messages.find((m) => m.sender === "user" && m.text);
    if (!userMsg) return "No title";
    const words = userMsg.text!.split(" ");
    return words.slice(0, 3).join(" ") + (words.length > 3 ? "..." : "");
  };

  const saveHelperNumber = () => {
    if (!helperNumber) {
      alert("Introdu un număr valid!");
      return;
    }
    localStorage.setItem("HELPER_NUMBER", helperNumber);
    setSettingsOpen(false);
    alert("Număr salvat!");
  };

  const sendLocationToHelper = () => {
    if (!helperNumber) {
      alert("NU este setat niciun număr de ajutor!");
      return;
    }
    if (!navigator.geolocation) {
      alert("Geolocation not supported");
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        const message = `🚨 ALERTĂ!\nAm nevoie de ajutor!\nLocația mea este:\nhttps://www.google.com/maps?q=${latitude},${longitude}`;
        const whatsappLink = `https://wa.me/${helperNumber}?text=${encodeURIComponent(message)}`;
        window.open(whatsappLink, "_blank");
        setPanicOpen(false);
      },
      () => {
        alert("Nu am putut obține locația!");
      }
    );
  };

  return (
    <div
      ref={sidebarRef}
      className={`bg-gray-900 text-white border-r-2 border-blue-600 transition-all duration-300 flex-shrink-0 ${
        showConversations ? "w-64" : "w-28"
      } flex flex-col py-4`}
    >
      {/* Logo */}
      <GiAngelWings size={36} className="mx-auto mb-4" />

      {/* Primele două iconițe: Settings și Panic */}
      <button
        className="mx-auto mb-4 p-2 bg-blue-600 rounded-full hover:bg-blue-700"
        onClick={() => setSettingsOpen(true)}
      >
        <FiSettings size={20} />
      </button>

      <button
        className="mx-auto mb-4 p-2 bg-red-600 rounded-full hover:bg-red-700"
        onClick={() => setPanicOpen(true)}
      >
        <FiAlertCircle size={24} />
      </button>

      {/* Următoarele iconițe: New Conversation și InfoBox */}
      <button
        className="mx-auto mb-2 p-2 rounded hover:text-blue-500"
        onClick={newConversation}
      >
        <FiPlus size={24} />
      </button>

      <InfoBox />

      {/* Download */}
      <button
        className="mx-auto mb-4 hover:text-blue-500"
        onClick={() => downloadConversation(activeConversationId)}
      >
        <FiDownload size={24} />
      </button>

      {/* Search (ultima iconiță) */}
      <button
        className="mx-auto mb-2 hover:text-blue-500"
        onClick={() => setShowConversations(!showConversations)}
      >
        <FiSearch size={24} />
      </button>

      {/* List of Conversations */}
      {showConversations && (
        <div className="flex-1 overflow-y-auto">
          {conversations.map((conv: Conversation) => (
            <div
              key={conv.id}
              className={`px-3 py-2 cursor-pointer rounded hover:bg-blue-700 ${
                conv.id === activeConversationId ? "bg-blue-600" : ""
              }`}
              onClick={() => setActiveConversation(conv.id)}
            >
              {conv.messages.length === 0
                ? "Welcome! Start your conversation here."
                : getConversationTitle(conv)}
            </div>
          ))}
        </div>
      )}

      {/* Settings Modal */}
      {settingsOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white text-black p-6 rounded-lg w-80 relative text-center">
            <button
              className="absolute top-2 right-2"
              onClick={() => setSettingsOpen(false)}
            >
              <FiX size={20} />
            </button>

            <h2 className="text-lg font-semibold mb-4">
              Set the help contact
            </h2>

            <input
              type="text"
              value={helperNumber}
              onChange={(e) => setHelperNumber(e.target.value)}
              placeholder="Ex: 40733146127"
              className="w-full border p-2 rounded mb-4"
            />

            <button
              className="px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
              onClick={saveHelperNumber}
            >
              SAVE
            </button>
          </div>
        </div>
      )}

      {/* Panic Modal */}
      {panicOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white text-black p-6 rounded-lg w-80 relative text-center">
            <button
              className="absolute top-2 right-2"
              onClick={() => setPanicOpen(false)}
            >
              <FiX size={20} />
            </button>

            <h2 className="text-lg font-semibold mb-4">
              Do you want to send your location to your help contact?
            </h2>

            <button
              className="mt-4 px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700"
              onClick={sendLocationToHelper}
            >
              SEND LOCATION 
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
